const menu = {
    // Salate
    '1': {'name': 'Gemischter Salat', 'Klein': 6.00, 'Groß': 7.00},
    '2': {'name': 'Bauernsalat', 'Klein': 6.50, 'Groß': 8.00},
    '3': {'name': 'Thunfischsalat', 'Klein': 6.50, 'Groß': 8.00},
    '4': {'name': 'Kebab Salat', 'Klein': 6.50, 'Groß': 8.50},
    '5': {'name': 'Gyros (Hähnchen) Salat', 'Klein': 6.50, 'Groß': 8.00},
    '6': {'name': 'Hawaii Salat', 'Klein': 6.50, 'Groß': 8.00},

    // Pizzen (Nummern 11 bis 47)
    '11': {'name': 'Margherita', 'Klein': 7.00, 'Groß': 8.00},
    '12': {'name': 'Mozzarella', 'Klein': 8.00, 'Groß': 9.00},
    '13': {'name': 'Salami', 'Klein': 7.50, 'Groß': 8.50},
    '14': {'name': 'Schinken', 'Klein': 7.50, 'Groß': 8.50},
    '15': {'name': 'Brokkoli', 'Klein': 8.00, 'Groß': 9.50},
    '16': {'name': 'Funghi', 'Klein': 8.00, 'Groß': 9.00},
    '17': {'name': 'Quattro', 'Klein': 8.00, 'Groß': 9.50},
    '18': {'name': 'Hawaii', 'Klein': 8.00, 'Groß': 9.50},
    '19': {'name': 'Vegetaria', 'Klein': 8.00, 'Groß': 9.50},
    '20': {'name': 'Salami Prosciutto', 'Klein': 8.00, 'Groß': 9.50},
    '21': {'name': 'Prosciutto Tonno', 'Klein': 8.00, 'Groß': 9.50},
    '22': {'name': 'Mista', 'Klein': 8.50, 'Groß': 9.50},
    '23': {'name': 'Sucuk', 'Klein': 8.50, 'Groß': 9.50},
    '24': {'name': 'Veneciana', 'Klein': 8.00, 'Groß': 9.50},
    '25': {'name': 'Capricciosa', 'Klein': 8.00, 'Groß': 9.50},
    '26': {'name': 'Isimo', 'Klein': 7.50, 'Groß': 9.00},
    '27': {'name': 'Americana', 'Klein': 7.50, 'Groß': 9.00},
    '28': {'name': '4 Sorten Käse', 'Klein': 9.50, 'Groß': 11.00},
    '29': {'name': 'Pizza Gyros (Hähnchen)', 'Klein': 7.50, 'Groß': 10.00},
    '30': {'name': 'Pizza Arian', 'Klein': 8.00, 'Groß': 10.50},
    '31': {'name': 'Pizza Aram', 'Klein': 8.00, 'Groß': 10.00},
    '32': {'name': 'Diabolo', 'Klein': 8.00, 'Groß': 10.00},
    '33': {'name': 'Prosciutto', 'Klein': 9.50, 'Groß': 11.50},
    '34': {'name': 'Venedig', 'Klein': 9.00, 'Groß': 10.00},
    '35': {'name': 'Dorfbrunnen', 'Klein': 8.50, 'Groß': 10.00},
    '36': {'name': 'Erika Pizza', 'Klein': 8.50, 'Groß': 10.00},
    '37': {'name': 'Siciliana', 'Klein': 8.50, 'Groß': 10.00},
    '38': {'name': 'Fantastika', 'Klein': 9.00, 'Groß': 10.00},
    '39': {'name': 'Spinat Gorgonzola', 'Klein': 8.50, 'Groß': 10.00},
    '40': {'name': 'Pizza Bütter', 'Klein': 8.00, 'Groß': 10.00},
    '41': {'name': 'Calzone', 'Normal': 10.50},
    '42': {'name': 'Kebab Pizza', 'Klein': 8.00, 'Groß': 10.50},
    '43': {'name': 'Pizza Larissa', 'Klein': 8.50, 'Groß': 11.00},
    '44': {'name': 'Pizza Hamet', 'Klein': 8.00, 'Groß': 10.00},
    '45': {'name': 'Pizza Lina', 'Klein': 8.50, 'Groß': 11.00},
    '46': {'name': 'Kebab Calzone', 'Normal': 10.00},
    '47': {'name': 'Wow Pizza', 'Normal': 12.50},

    // Kebab-Gerichte
    '60': {'name': 'Kebab', 'Normal': 6.00},
    '61': {'name': 'Kebab vegetarisch', 'Normal': 6.00},
    '62': {'name': 'Jumbo Kebab', 'Normal': 8.50},
    '63': {'name': 'Kebab Tüte', 'Normal': 6.50},
    '64': {'name': 'Kebab Dürüm', 'Normal': 7.00},
    '65': {'name': 'Kebab überbacken', 'Normal': 9.00},
    '66': {'name': 'Kebab Teller', 'Normal': 10.50},
    '67': {'name': 'Kinder Kebabteller', 'Normal': 8.50},
    '68': {'name': 'Chef Teller', 'Normal': 11.50},
    '69': {'name': 'Chef Platte für 2 Personen', 'Normal': 20.00},

    // Nummer 70: Kebab Spezial mit Abfrage "Mit Fleisch" oder "Ohne Fleisch"
    '70': {'name': 'Kebab Spezial', 'Mit Fleisch': 7.50, 'Ohne Fleisch': 5.50},

    // Teller-Gerichte
    '91': {'name': 'Gyros (Hähnchen) Teller (groß)', 'Normal': 10.50},
    '92': {'name': 'Gyros (Hähnchen) Teller (klein)', 'Normal': 9.50},
    '93': {'name': 'Gyros (Hähnchen) in Fladenbrot', 'Normal': 6.00},
    '94': {'name': 'Grill Teller', 'Normal': 13.00},
    '97': {'name': 'Bauern Teller', 'Normal': 12.00},
    '99': {'name': '3 Schweinesteaks', 'Normal': 13.00},
    '100': {'name': 'Bifteki', 'Normal': 11.50},
    '103': {'name': 'Mykonos Teller', 'Normal': 12.50},
    '104': {'name': 'Schnitzel Hawaii', 'Normal': 11.00},
    '105': {'name': 'Schnitzel Bolognese', 'Normal': 10.50},

    // Rollo-Gerichte
    '150': {'name': 'Rollo Tonno', 'Normal': 9.00},
    '151': {'name': 'Rollo Kebab', 'Normal': 9.50},
    '152': {'name': 'Rollo Gyros (Hähnchen)', 'Normal': 9.50},
    '153': {'name': 'Rollo Vegetarisch', 'Normal': 9.50},

    // Pasta mit Überbacken Option (Nummern 50 bis 56)
    '50': {'name': 'Bolognese', 'Überbacken': 8.50, 'Nein': 7.50},
    '51': {'name': 'Tomatensauce', 'Überbacken': 8.50, 'Nein': 7.50},
    '52': {'name': 'Schinken-Sahnesauce', 'Überbacken': 8.50, 'Nein': 7.50},
    '53': {'name': 'Gorgonzola-Sahnesauce mit Spinat', 'Überbacken': 8.50, 'Nein': 7.50},
    '54': {'name': '4 Sorten Käse-Sahnesauce', 'Überbacken': 8.50, 'Nein': 7.50},
    '55': {'name': 'Thunfisch-Schinken-Sahnesauce', 'Überbacken': 8.50, 'Nein': 7.50},
    '56': {'name': 'Arrabiata Tomatensauce (scharf)', 'Überbacken': 8.50, 'Nein': 7.50},

    // Schnitzel mit Soße Option (Nummer 106)
    '106': {'name': 'Schnitzel', 'Mit Soße': 9.50, 'Nein': 7.50},

    // Getränke (Nummer 159) mit Abfrage „0,33 L“ oder „1 L“
    '159': {'name': 'Getränke', '0,33 L': 2.50, '1 L': 3.00},

    // Extra-Beilagen
    '129': {'name': 'Chicken Nuggets', 'Normal': 4.00},
    '131': {'name': 'Tzatziki', 'Normal': 2.30},
    '132': {'name': 'Knoblauchsauce', 'Normal': 2.30},
    '133': {'name': 'Peperoni', 'Normal': 2.00},
    '134': {'name': 'Hirtenkäse', 'Normal': 3.50},
    '135': {'name': 'Oliven', 'Normal': 2.00},
    '136': {'name': 'Kroketten', 'Normal': 3.00},
    '137': {'name': 'Pizzabrötchen', 'Normal': 2.50},
    '138': {'name': 'Pommes', 'Normal': 3.00},
    '139': {'name': 'Ketchup oder Mayonnaise', 'Normal': 0.40},

    // Hamburger-Gerichte
    '140': {'name': 'Hamburger 100gr', 'Normal': 5.50},
    '141': {'name': 'Cheeseburger 100gr', 'Normal': 6.00},
    '142': {'name': 'Chicken Burger 100gr', 'Normal': 6.00},
    '143': {'name': 'Chili Cheese Burger', 'Normal': 6.00},
    '144': {'name': 'Riesen Currywurst', 'Normal': 7.50}
};

let currentInput = '';
let firstInput = '';
let quantity = 1;
let selectedRow = null;
let isMultiplying = false;

function appendNumber(number) {
    currentInput += number;
    document.getElementById('display').innerText = currentInput;
}

function clearDisplay() {
    if (selectedRow) {
        deleteItem(selectedRow);
    } else {
        currentInput = '';
        document.getElementById('display').innerText = '';
        quantity = 1;  // Reset the quantity after clearing
        isMultiplying = false;  // Reset the multiplying flag
    }
}

function multiply() {
    if (currentInput !== '') {
        firstInput = currentInput;
        quantity = parseInt(firstInput);
        currentInput = '';
        document.getElementById('display').innerText = 'x ' + quantity;
        isMultiplying = true;  // Set multiplying flag
    }
}

function confirmNumber() {
    if (menu[currentInput]) {
        const item = menu[currentInput];

        // Abfrage für Getränke (0,33 L oder 1 L)
        if (currentInput === '159') {
            document.getElementById('size-buttons').style.display = 'block';
            document.getElementById('size-buttons').innerHTML = `
                <button onclick="selectSize('0,33 L', menu['159'])">0,33 L</button>
                <button onclick="selectSize('1 L', menu['159'])">1 L</button>
            `;
        }
        // Abfrage für Schnitzel (Mit Soße oder Nein)
        else if (currentInput === '106') {
            document.getElementById('size-buttons').style.display = 'block';
            document.getElementById('size-buttons').innerHTML = `
                <button onclick="selectSize('Mit Soße', menu['106'])">Mit Soße</button>
                <button onclick="selectSize('Nein', menu['106'])">Nein</button>
            `;
        }
        // Abfrage für Nummer 70 (Mit Fleisch oder Ohne Fleisch)
        else if (currentInput === '70') {
            document.getElementById('size-buttons').style.display = 'block';
            document.getElementById('size-buttons').innerHTML = `
                <button onclick="selectSize('Mit Fleisch', menu['70'])">Mit Fleisch</button>
                <button onclick="selectSize('Ohne Fleisch', menu['70'])">Ohne Fleisch</button>
            `;
        }
        // Abfrage für Pasta (Überbacken oder Nein)
        else if (['50', '51', '52', '53', '54', '55', '56'].includes(currentInput)) {
            document.getElementById('size-buttons').style.display = 'block';
            document.getElementById('size-buttons').innerHTML = `
                <button onclick="selectSize('Überbacken', menu[currentInput])">Überbacken</button>
                <button onclick="selectSize('Nein', menu[currentInput])">Nein</button>
            `;
        }
        // Standardartikel mit Klein/Groß-Optionen oder Normalpreis
        else if (item.Klein || item.Groß) {
            document.getElementById('size-buttons').style.display = 'block';
            filterSizeButtons(item);
        } else if (item.Normal) {
            const price = item.Normal * quantity;
            addItemToOrder(item.name, 'Normal', price, quantity);
            clearDisplay();
        }
    } else {
        alert('Ungültige Nummer');
        clearDisplay();
    }
}

function filterSizeButtons(item) {
    const buttons = document.getElementById('size-buttons').getElementsByTagName('button');
    for (let i = 0; i < buttons.length; i++) {
        const button = buttons[i];
        if (item[button.innerText] !== undefined) {
            button.style.display = 'inline-block';
            button.onclick = () => selectSize(button.innerText, item);
        } else {
            button.style.display = 'none';
        }
    }
}

function selectSize(size, item) {
    const price = item[size] * quantity;
    addItemToOrder(item.name, size, price, quantity);
    clearDisplay();
    document.getElementById('size-buttons').style.display = 'none';
}

function addItemToOrder(name, size, price, quantity) {
    const table = document.getElementById('order-list');
    const row = table.insertRow();
    row.insertCell(0).innerText = quantity + 'x ' + name;
    row.insertCell(1).innerText = size;
    row.insertCell(2).innerText = price.toFixed(2) + ' €';

    row.addEventListener('click', () => {
        if (selectedRow) {
            selectedRow.classList.remove('selected');
        }
        row.classList.add('selected');
        selectedRow = row;
    });

    updateTotal();
}

function deleteItem(row) {
    row.remove();
    updateTotal();
    selectedRow = null;
}

function updateTotal() {
    const rows = document.getElementById('order-list').rows;
    let total = 0;
    for (let i = 0; i < rows.length; i++) {
        const price = parseFloat(rows[i].cells[2].innerText.replace(' €', ''));
        total += price;
    }
    document.getElementById('total-price').innerText = 'Gesamt: ' + total.toFixed(2) + ' €';
}

function resetOrder() {
    document.getElementById('order-list').innerHTML = '';
    updateTotal();
    selectedRow = null;
    clearDisplay();
    quantity = 1;
    isMultiplying = false;  // Reset multiplying flag after resetting
}

function selectZutaten() {
    document.getElementById('size-buttons').style.display = 'block';
    const item = {
        name: 'Zutaten',
        Klein: 0.50,
        Groß: 1.00
    };
    filterSizeButtons(item);
}

function selectDelivery() {
    document.getElementById('size-buttons').style.display = 'block';
    const item = {
        name: 'Lieferung',
        Innerhalb: 2.00,
        Außerhalb: 3.00
    };
    filterSizeButtons(item);
}